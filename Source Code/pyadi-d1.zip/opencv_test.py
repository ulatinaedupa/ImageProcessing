# Importamos la librería de OpenCV
import cv2 

img = cv2.imread('gargantua.jpg', cv2.IMREAD_COLOR) # Leemos la imagen a color y
                                     # la almacenamos  

cv2.imshow("Display the image", img) # Desplegamos la imagen cargada

while True:                          # nos mantenemos hasta presionar ESC
    c = cv2.waitKey(20)
    if c == 27:
    	break

cv2.destroyAllWindows()              # destruimos las ventanas creadas